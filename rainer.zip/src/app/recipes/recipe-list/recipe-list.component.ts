import { Component, OnInit } from '@angular/core';

import {Recipe} from'../recipe.model'

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
 recipes:Recipe[] =[
   new Recipe('Torticas de morón','un clásico dulce cubano','https://i0.hippopx.com/photos/574/513/111/flaky-pastry-puff-paste-puff-pastry-tart-preview.jpg'),
    new Recipe('Galletas de maní','delicioso y nutritivo ','https://cdn.pixabay.com/photo/2017/06/10/10/46/dim-sum-2389599_960_720.jpg')

   
 ];
  constructor() { }

  ngOnInit() {
  }

}